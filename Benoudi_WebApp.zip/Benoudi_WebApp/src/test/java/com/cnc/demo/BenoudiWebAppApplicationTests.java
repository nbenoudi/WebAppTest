package com.cnc.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.cnc.demo.Model.User;
import com.cnc.demo.User_Service.UserRepository;
//import com.cnc.demo.User_Service.UserService;

@SpringBootTest

class BenoudiWebAppApplicationTests {
	@MockBean
	private UserRepository repository;
	@Test
	public void getUsersTest() {
		// Bevor das Test zu testen ich habe User(1,n.benoudi@gmail,Benoudi,123,Nasser
		List<User> users = repository.findByNachname("Benoudi");
		assertEquals(users.get(0).getNachname(),"Benoudi");
		}
	
	
	@Test
	void contextLoads() {
	}

}
