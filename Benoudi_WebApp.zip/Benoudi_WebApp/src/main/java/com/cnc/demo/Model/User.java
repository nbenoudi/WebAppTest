package com.cnc.demo.Model;

/**
 * Benoudi Nasser
 * 20.08.2019
 * *****************************************User Entity Model*******************************
 */
import javax.persistence.Column;
/**
 * @author Benoudi Nasser
 * 20.08.2019
 */
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.data.annotation.Transient;

@Entity
@Table(name = "Users")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "User_id")
	private int User_ID;
	@Column(name = "Vorname")
	private String Vorname;
	@Column(name = "nachname")
	private String nachname;

	@Column(name = "Email")
	// @NotEmpty(message = "Please provide an e-mail")
	private String Email;

	@Column(name = "Password")
	@Transient
	private String Password;

	// Getter und Setter Methoden
	public int getUser_ID() {
		return User_ID;
	}

	public void setUser_ID(int user_ID) {
		this.User_ID = user_ID;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		this.Email = email;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		this.Password = password;
	}

	public String getVorname() {
		return Vorname;
	}

	public void setVorname(String vorname) {
		this.Vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	// To String Methoden
	@Override
	public String toString() {
		return "User [User_ID=" + User_ID + ", Email=" + Email + ", Password=" + Password + ", Vorname=" + Vorname
				+ ", Nachname=" + nachname + ", getUser_ID()=" + getUser_ID() + ", getEmail()=" + getEmail()
				+ ", getPassword()=" + getPassword() + ", getVorname()=" + getVorname() + ", getNachname()="
				+ getNachname() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

	// ....
}
