package com.cnc.demo.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cnc.demo.Model.User;
import com.cnc.demo.User_Service.UserService;

@RestController
public class UserController {
	@Autowired
	private UserService service;

	@GetMapping(value = "/bip")
	public String showSignUpForm(User user) {
		return "Anmeldung";
	}

	@GetMapping(value = "/")
	public String home() {
		return "home";
	}

	// to Create benuzen wir Post annotation
	@PostMapping(value = "/addUser")
	public User speicherUser(@RequestBody User user) {
		user = service.addUser(user);
		return user;
	}

	// Ausgaben als Json Format bei Client liefern
	@GetMapping(value = "/getUsers", produces = "application/json")
	public List<User> findallUser() {
		return service.getUsers();
	}

	// Rest API to get User nach Nachname
	@GetMapping(value = "/getUserByNachname/{nachname}")
	public List<User> getUserByNachname(@PathVariable("Nachname") String nachname) {
		return service.getUserbyNachname(nachname);
	}

	// Rest API to delete user Passed in argument der Funktion Loechen.
	@DeleteMapping(value = "/loeschen")
	public User loeschen(@RequestBody User user) {
		return service.deleteUser(user);
	}
}
