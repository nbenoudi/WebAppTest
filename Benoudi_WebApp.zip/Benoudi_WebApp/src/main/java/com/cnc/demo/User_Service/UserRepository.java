package com.cnc.demo.User_Service;
/**
 * @author Benoudi Nasser
 * 20.08.2019
 */

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.cnc.demo.Model.User;

public interface UserRepository extends CrudRepository<User, Integer> {
	// Achtung bei Geniric Klassen nicht primitive Typen wie ( int, long , ... ) als
	// Parametern angeben
	// sondern die Primitive Typen wie Integer, Long,...

	@Query
	List<User> findByNachname(@Param(value = "Nachname") String Nachname);
	// @Query
	// List<User> findByEmailAndPassword(@Param(value = "Email") String email
	// ,@Param(value = "Password")String password);
}
