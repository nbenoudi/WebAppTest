package com.cnc.demo.User_Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cnc.demo.Model.User;

@Service
public class UserService {
	@Autowired
	private UserRepository repository;

	public User addUser(User user) {
		return repository.save(user);
	}

	public List<User> getUsers() {
		List<User> users = (List<User>) repository.findAll();
		return users;
	}

	// get List of User mit Nachname
	public List<User> getUserbyNachname(String nachname) {
		List<User> users = (List<User>) repository.findByNachname(nachname);
		return users;
	}

	public User deleteUser(User user) {
		repository.delete(user);
		return user;
	}
}
